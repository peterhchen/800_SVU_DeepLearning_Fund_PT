# Deep Q-network in PyTorch

## To Train dqn Agent
<pre>
python main.py
</pre>

## To test trained agent
<pre>
python dqn_agent_demo.py
</pre>

## To test random agent
<pre>
python random_cartpole_agent.py
</pre>
